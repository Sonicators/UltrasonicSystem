//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
//      Copyright (C) 2015 Peter Walsh, Milford, NH 03055
//      All Rights Reserved
//
//  FILE
//      ResonanceFinder.c
//
//  DESCRIPTION
//
//      This is a simple AVR program to measure a transducer resonant frequency
//
//      It is used as part of the horn tuning process. Determine the transducer
//        resonant frequency (without the horn) first, then repeatedly attach the
//        horn, determine the new resonant frequency, then shorten the horn a little.
//        Repeat until the horn/transducer combination resonates at the original
//        transducer frequency.
//
//      This program requires an associated AD9833 sine generator, and some support
//        circuitry. See project directory for details.
//
//  SYNOPSIS
//
//      Connect a transducer to the clips of the daughterboard.
//
//      Compile, load, and run this module. The program will accept frequency sweep 
//        commands via the serial port, and determine the resonant frequency of the
//        transducer.
//
//      See the HELP_SCREEN definition below for a list of available commands
//
//  VERSION:    2011.11.07
//
//////////////////////////////////////////////////////////////////////////////////////////
//
//  MIT LICENSE
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy of
//    this software and associated documentation files (the "Software"), to deal in
//    the Software without restriction, including without limitation the rights to
//    use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
//    of the Software, and to permit persons to whom the Software is furnished to do
//    so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//    all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
//    INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
//    PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//    OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
//    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

#include <avr/interrupt.h>
#include <util/delay.h>

#include <string.h>
#include <stdlib.h> 
#include <stdint.h>

#include "AD9833.h"
#include "AtoD.h"
#include "UART.h"
#include "GetLine.h"
#include "Parse.h"
#include "VT100.h"

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// Data declarations
//
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

//
// VolPot setup
//
#include "AD8400.h"

uint16_t    Volume;

#define VolPot_PORT             D
#define VolPot_BIT              6
#define VolPot_MAXR             1000
#define VolPot_MAX_WIPER        (AD8400_STEPS-1)

#define VolPotInit              AD8400Init(VolPot_PORT,VolPot_BIT)
#define VolPotSetWiper(_w_)     AD8400SetWiper(VolPot_PORT,VolPot_BIT,_w_)
#define VolPotSetResist(_r_)    AD8400SetResist(VolPot_PORT,VolPot_BIT,VolPot_MAXR,_r_)
#define VolPotIncr              AD8400Incr(VolPot_PORT,VolPot_BIT)
#define VolPotDecr              AD8400Decr(VolPot_PORT,VolPot_BIT)

#define VolPotR2W(_r_)          AD8400_R2W(VolPot_MAXR,_r_)
#define VolPotW2R(_w_)          AD8400_W2R(VolPot_MAXR,_w_)


//
// Static layout of the help screen
//
#define HELP_SCREEN "\
SW <start> <end> <incr>  Sweep frequencies\r\n\
S1                       Sweep 20000 30000 100\r\n\
ME <freq>   Measure individual frequency\r\n\
FR <freq>   Generate frequency\r\n\
ON          Enable square wave output\r\n\
OFF         Stop   square wave\r\n\
ST          Show status\r\n\
VO <#>      Set the volume\r\n\
+           Volume up\r\n\
-           Volume down\r\n\
++          Volume up 10\r\n\
--          Volume down 10\r\n\
HE          Show this help panel\r\n\
?           Show this help panel\r\n\
"

#define BEEP    "\007"
#define ESC_CMD "\033"

#define     MIN_FREQ    200
#define     MAX_FREQ    32000
#define     MIN_INCR    1

#define     S1_START    20000
#define     S1_END      32000
#define     S1_INCR     100

uint16_t    AtoD;

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// ParseFreq - Parse numeric input as frequency
//
// Inputs:      None.
//
// Outputs:     Parsed frequency, or 0 if error
//
static uint16_t ParseFrequency(void) {

    char *FreqText = ParseToken();

    if( FreqText == NULL || strlen(FreqText) == 0 ) {
        PrintString("Arg required\r\n");
        PrintString("Type '?' for help\r\n");
        PrintCRLF();
        return 0;
        }

    //
    // Token entered - parse and return to user
    //
    uint16_t Freq = atoi(FreqText);

    if( Freq >= 0 )
        return Freq;

    //
    // If freq out of range, print error and ignore
    //
    PrintString("Freq out of range (");
    PrintString(FreqText);
    PrintString("), must be ");
    PrintD(MIN_FREQ,0);
    PrintString(" to ");
    PrintD(MAX_FREQ,0);
    PrintCRLF();
    PrintString("Type '?' for help\r\n");
    PrintCRLF();
    return 0;
    }


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// MeasureImpedance - Measure the impedance, via the AtoD
//
// Inputs:      None.
//
// Outputs:     None - the global AtoD value is set
//
static void MeasureImpedance(uint16_t Freq) {

    //
    // Start the square wave output
    //
    AD9833Output(AD9833_SIN,Freq);


    //
    // Wait a little for the transducer to settle and the integrating
    //   capacitor to charge.
    //
    _delay_ms(100);

    uint16_t    AtoDTotal = 0;

#define NUM_SAMPLES     20
    for( uint8_t i=0; i<NUM_SAMPLES; i++ ) {
        StartAtoD();
        while( !AtoDComplete() );
        AtoDTotal += GetAtoD(0);
        }

    AtoD = AtoDTotal/NUM_SAMPLES;

    //
    // All done - turn off AtoD just to be safe
    //
    AD9833Output(AD9833_OFF,0);

    PrintD(Freq,5);
    PrintString(": ");
    PrintD(AtoD,0);
    PrintCRLF();
    }


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// Sweep - Sweep from FreqStart to FreqEnd, measuring impedance
//
// Inputs:      None.
//
// Outputs:     None.
//
static void Sweep(uint16_t StartFreq,uint16_t EndFreq,uint16_t Incr) {

    PrintCRLF();
    PrintString("Begin sweep ");
    PrintD(StartFreq,0);
    PrintString(" to ");
    PrintD(EndFreq,0);
    PrintString(" step ");
    PrintD(Incr,0);
    PrintCRLF();
    PrintCRLF();

    uint16_t    FreqOfMin = 0;
    uint16_t    FreqOfMax = 0;
    uint16_t    MinAtoD   = 65535;
    uint16_t    MaxAtoD   = 0;

    while( StartFreq <= EndFreq ) {
        MeasureImpedance(StartFreq);

        if( AtoD < MinAtoD ) {
            MinAtoD = AtoD;
            FreqOfMin = StartFreq;
            }

        if( AtoD > MaxAtoD ) {
            MaxAtoD = AtoD;
            FreqOfMax = StartFreq;
            }

        StartFreq += Incr;
        }

    PrintCRLF();
    PrintCRLF();

    PrintString("Min at: ");
    PrintD(FreqOfMin,0);
    PrintString(" Hz (");
    PrintD(MinAtoD,0);
    PrintString(")");
    PrintCRLF();

    PrintString("Max at: ");
    PrintD(FreqOfMax,0);
    PrintString(" Hz (");
    PrintD(MaxAtoD,0);
    PrintString(")");
    PrintCRLF();

    PrintCRLF();
    PrintCRLF();
    }


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// PrintStatus - Print out the status
//
// Inputs:      None.
//
// Outputs:     None.
//
static void PrintStatus(void) {

    PrintCRLF();

    PrintString("Freq = ");
    PrintD(AD9833GetFreq(),0);
    if( AD9833IsOn() ) PrintString(" (on)");
    else               PrintString(" (off)");

    PrintCRLF();
    }


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// ResonanceFinder - Measure a transducer resonant frequency
//
// Inputs:      None. (Embedded program - no command line options)
//
// Outputs:     None. (Never returns)
//
int __attribute__((OS_main))  main(void) {

    //////////////////////////////////////////////////////////////////////////////////////
    //
    // Initialize the UART
    //
    UARTInit();
    SPIInit;
    AD9833Init();
    VolPotInit;
    AtoDInit();

    sei();                              // Enable interrupts

    Volume = 5;
    VolPotSetWiper(Volume);

    ClearScreen;


    //
    // End of init
    //
    //////////////////////////////////////////////////////////////////////////////////////

    PrintString("***************\r\n");
    PrintString("ResonanceFinder\r\n");
    PrintString("***************\r\n");
    PrintString("Type '?' for help");
    PrintCRLF();

    PrintStatus();

    GetLineInit();

    //////////////////////////////////////////////////////////////////////////////////////
    //
    // All done with init,
    // 
    while(1) {
        //
        // Process user commands
        //
        ProcessSerialInput(GetUARTByte());
        } 
    }

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//
// SerialCommand - Manage command lines for this program
//
// Inputs:      Command line typed by user
//
// Outputs:     None.
//
void SerialCommand(char *Line) {
    char    *Command;

    ParseInit(Line);
    Command = ParseToken();

    //
    // Universally accept <ESC> as stop the output
    //
    if( StrEQ(Command,ESC_CMD) ) {
        AD9833Output(AD9833_OFF,0);
        PrintCRLF();
        PrintString("Output off\r\n");
        return;
        }


    //
    // ME - Measure individual frequency
    //
    if( StrEQ(Command,"ME") ) {
        uint16_t Freq = ParseFrequency();

        if( Freq == 0 )
            return;

        MeasureImpedance(Freq);
        PrintCRLF();
        return;
        }


    //
    // FR - Frequency generation (continuous)
    //
    if( StrEQ(Command,"FR") ) {
        uint16_t Freq = ParseFrequency();

        if( Freq == 0 )
            return;

        AD9833Output(AD9833_SIN,Freq);
        PrintString("Frequency is ");
        PrintD(Freq,0);
        PrintCRLF();
        PrintString("Volume is ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }


    //
    // S1 - Perform fixed sweep from MIN_FREQ to MAX_FREQ
    //
    if( StrEQ(Command,"S1") ) {
        Sweep(S1_START,S1_END,S1_INCR);
        return;
        }

    //
    // SW - Perform frequency/measurement sweep
    //
    if( StrEQ(Command,"SW") ) {
        uint16_t StartFreq = ParseFrequency();

        if( StartFreq == 0 )
            return;

        uint16_t EndFreq = ParseFrequency();

        if( EndFreq == 0 )
            return;

        char *IncrText = ParseToken();

        if( IncrText == NULL || strlen(IncrText) == 0 ) {
            PrintString("Incr arg required\r\n");
            PrintString("Type '?' for help\r\n");
            PrintCRLF();
            return;
            }

        //
        // Incr entered - parse and return to user
        //
        uint16_t Incr = atoi(IncrText);

        if( Incr == 0 ) {
            PrintString("Incr out of range (");
            PrintString(IncrText);
            PrintString("), must be > 0\r\n");
            PrintCRLF();
            PrintString("Type '?' for help\r\n");
            PrintCRLF();
            return;
            }

        Sweep(StartFreq,EndFreq,Incr);
        return;
        }


    //
    // ON - Turn squarewave on
    //
    if( StrEQ(Command,"ON") ) {
        AD9833Output(AD9833_SIN,AD9833GetFreq());
        return;
        }


    //
    // OFF - Turn squarewave off
    //
    if( StrEQ(Command,"OFF") ) {
        AD9833Output(AD9833_OFF,0);
        return;
        }


    //
    // TRI - Turn triangle on
    //
    if( StrEQ(Command,"TRI") ) {
        AD9833Output(AD9833_TRI,AD9833GetFreq());
        return;
        }

    //
    // SIN - Turn sinewave on
    //
    if( StrEQ(Command,"SIN") ) {
        AD9833Output(AD9833_SIN,AD9833GetFreq());
        return;
        }

    //
    // SQ - Turn squarewave on
    //
    if( StrEQ(Command,"SQ") ) {
        AD9833Output(AD9833_SQ,AD9833GetFreq());
        return;
        }

    //
    // ST - Print status
    //
    if( StrEQ(Command,"ST") ) {
        PrintStatus();
        return;
        }


    //
    // D - Debug command
    //
    if( StrEQ(Command,"D") ) {
        return;
        }

    //
    // VO # - Set the volume
    //
    if( StrEQ(Command,"VO") ) {
        char *VolText = ParseToken();

        if( VolText == NULL || strlen(VolText) == 0 ) {
            PrintString("Volume arg required\r\n");
            PrintString("Type '?' for help\r\n");
            PrintCRLF();
            return;
            }

        //
        // VolText entered - parse and set
        //
        uint16_t NewVol = atoi(VolText);

        if( NewVol < 0 ||
            NewVol > VolPot_MAX_WIPER ) {
            PrintString("Volume out of range (");
            PrintString(VolText);
            PrintString("), must be 0 to ");
            PrintD(VolPot_MAX_WIPER,0);
            PrintCRLF();
            PrintString("Type '?' for help\r\n");
            PrintCRLF();
            return;
            }

        Volume = NewVol;
        VolPotSetWiper(Volume);
        PrintString("Volume is now ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }

    //
    // + - Move the volume up
    //
    if( StrEQ(Command,"+") ) {
        if( Volume < VolPot_MAX_WIPER )
            Volume++;
        VolPotSetWiper(Volume);
        PrintString("Volume is now ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }

    //
    // - - Move the volume down
    //
    if( StrEQ(Command,"-") ) {
        if( Volume > 0 )
            Volume--;
        VolPotSetWiper(Volume);
        PrintString("Volume is now ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }


    //
    // ++ - Move the volume up by 10
    //
    if( StrEQ(Command,"++") ) {
        if( Volume < VolPot_MAX_WIPER-10 ) Volume += 10;
        else                               Volume  = VolPot_MAX_WIPER;
        VolPotSetWiper(Volume);
        PrintString("Volume is now ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }

    //
    // -- - Move the volume down by 10
    //
    if( StrEQ(Command,"--") ) {
        if( Volume > 10 ) Volume -= 10;
        else              Volume  = 0;
        VolPotSetWiper(Volume);
        PrintString("Volume is now ");
        PrintD(Volume,0);
        PrintCRLF();
        return;
        }



    /////////////////////////////////////////////////////////////////////////////////////
    //
    // Regular commands follow
    //

    //
    // HE - Help screen
    //
    if( StrEQ(Command,"HE") ||
        StrEQ(Command,"?" ) ) {
        PrintCRLF();
        PrintString(HELP_SCREEN);
        PrintCRLF();
        return;
        }


    //
    // Not a recognized command. Let the user know he goofed.
    //
    PrintStringP(PSTR(BEEP));
    PrintStringP(PSTR("Unrecognized Command \""));
    PrintString (Command);
    PrintStringP(PSTR("\"\r\n"));
    PrintString("Type '?' for help\r\n");
    PrintCRLF();
    }

