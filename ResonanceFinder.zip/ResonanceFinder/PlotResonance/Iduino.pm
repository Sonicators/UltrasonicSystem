#!/dev/null
#
##########################################################################################
##########################################################################################
##
##      Copyright (C) 2015 Joel Jennings, Milford, NH 03055
##      All Rights Reserved under the MIT license as outlined below.
##
##  FILE
##      Iduino.pm
##
##  DESCRIPTION
##
##      Object to manage communication with an Iduino on a serial port
##
##  DATA
##
##      ->{PortName}                    Text name of port (ie - "COM10")
##      ->{ReadTimeout}                 Seconds to wait for responses
##
##      ->{Port}                        Serial::Port device for communication
##
##  FUNCTIONS
##
##      ->new()                         Make a new interface
##
##      ->FindPort()                    Run through serial ports looking for Iduino
##      ->OpenIduino("COM10")           Open Iduino on specified port
##
##      ->WriteMsg($Msg)                Format and send message to Iduino
##      ->ReadMsg()->$Response          Read response from Iduino
##
##########################################################################################
##########################################################################################
##
##  MIT LICENSE
##
##  Permission is hereby granted, free of charge, to any person obtaining a copy of
##    this software and associated documentation files (the "Software"), to deal in
##    the Software without restriction, including without limitation the rights to
##    use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
##    of the Software, and to permit persons to whom the Software is furnished to do
##    so, subject to the following conditions:
##
##  The above copyright notice and this permission notice shall be included in
##    all copies or substantial portions of the Software.
##
##  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
##    INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
##    PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
##    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
##    OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
##    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
##
##########################################################################################
##########################################################################################

package Iduino;

use strict;
use warnings;
use Carp;

our $VERSION = '1.0';

use Win32::TieRegistry( Delimiter=>"/", ArrayValues=>0 );

##########################################################################################
##########################################################################################
##
## Data declarations
##
##########################################################################################
##########################################################################################

our $SerialsKey = "HARDWARE/DEVICEMAP/SERIALCOMM";

use constant DEFAULT_PORT    => "COM10";
use constant DEFAULT_TIMEOUT => 1;          # Seconds timeout looking for response

use constant HELP            => "?";

##########################################################################################
##########################################################################################
#
# Iduino - Generate a new object for Iduino communication
#
# Inputs:   Com port to open
#
# Outputs:  New Iduino object
#
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self  = bless {}, $class;

    $self->{ReadTimeout} = DEFAULT_TIMEOUT;

    return $self;
    }


##########################################################################################
##########################################################################################
#
# FindPort - Determine which serial port to use for Iduino communication
#
# Inputs:   None.
#
# Outputs:  TRUE  if a  Iduino was successfully found on a system port
#           FALSE if no Iduino (or no ports) were found
#
sub FindPort {
    my $self = shift;

    my $Ports = $Registry->{"LMachine/" . $SerialsKey}
        or  die "Can't open HKEY_LOCAL_MACHINE\\" . $SerialsKey . "(" . $^E . ")\n";

    foreach my $PortName (reverse sort keys %$Ports) {

#        print "Try port $Ports->{$PortName}\n";

        next
            unless $self->OpenIduino($Ports->{$PortName});

        $self->{PortName} = $Ports->{$PortName};
        return 1;
        }

    return 0;
    }


##########################################################################################
##########################################################################################
#
# OpenIduino - Open Iduino at specified serial port
#
# Inputs:   Name of serial port to open (ie - "COM10" or "/dev/tty4")
#
# Outputs:  TRUE  if port successfully opened and Iduino was seen
#           FALSE if cannot open port, or no Iduino seen, or whatever ($! is set)
#
sub OpenIduino {
    my $self     = shift;
    my $PortName = shift;

    #
    # Clean up previous port object, if there is one.
    #
    if( defined $self->{Port} ) {
        $self->{Port}->close;
        undef $self->{Port};
        }

    #
    # Try to open new port object, and set up for Iduino communication
    #
    my $Port;

    if( $^O =~ m/Win32/ ) {
        require Win32::SerialPort;
        $Port = new Win32::SerialPort($PortName,1);
        }
    else {
        require Device::SerialPort;
        $Port = new Device::SerialPort($PortName,1);
        }

    return 0
        unless $Port;

    $self->{Port} = $Port;

    $| = 1;                                 # Flush output immediately

    $self->{Port}->user_msg(1);
    $self->{Port}->databits(8);
    $self->{Port}->baudrate(19200);
    $self->{Port}->parity("none");
    $self->{Port}->stopbits(1);
    $self->{Port}->handshake("none");
    $self->{Port}->buffers(4096, 4096);
    $self->{Port}->binary(1);

    $self->{Port}->lookclear;               # Empty input buffers
    $self->{Port}->write_settings;

    #
    # Try to read from the Iduino using specified comm port.
    #
    #  '?' => Help command
    #
    $self->WriteMsg(HELP);

    my $Response = $self->ReadMsg();

    return 0
        unless defined $Response;

    return 0
        unless length($Response) > 10;

#print "====\n";
#print "$Response\n";
#print "====\n";

#    print "Iduino found on port $PortName\n";

    return 1;
    }


##########################################################################################
##########################################################################################
#
# WriteMsg - Write message to Iduino
#
# Inputs:   Message to send to Iduino
#
# Outputs:  None.
#
sub WriteMsg {
    my $self = shift;
    my $Msg  = shift;

    #
    # Call lookclear() on the port, in case the caller expects a response.
    #
    $self->{Port}->lookclear;

    $self->{Port}->write($Msg . "\r\n");
    }


##########################################################################################
##########################################################################################
#
# ReadMsg - Read message from Iduino
#
# Inputs:   None.
#
# Outputs:  The returned message, or undef if none (timed out)
#
# Note: port must be first opened, via call to $self->OpenPort(...);
#
sub ReadMsg {
    my $self = shift;

    my $Response;

    foreach ( 0 .. $self->{ReadTimeout} ) {
        $Response = $self->{Port}->lookfor;

        die "Aborted read $!" 
            unless defined $Response;

        if( $Response ) {
            #
            # Return the data to the user
            #
            return $Response;
            }

        sleep 1;
        }

    return undef;
    }



#
# Perl requires that a package file return a TRUE as a final value.
#
1;
