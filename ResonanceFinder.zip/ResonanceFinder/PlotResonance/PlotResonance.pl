#########################################################################################
##########################################################################################
##
##      Copyright (C) 2015 Joel Jennings, Milford, NH 03055
##      All Rights Reserved under the MIT license as outlined below.
##
##  FILE
##      PlotResonance.pl
##
##  DESCRIPTION
##      Get and plot the resonance data from the ResonanceFinder program connected
##        to a serial port.
##
##  USAGE
##
##      perl PlotResonance.pl
##
##      Get and plot the resonance data from the ResonanceFinder program connected
##        to a serial port.
##
##      -h, --help              Print the usage   info and exit
##      -v, --version           Print the version info and exit
##
##  DATA
##
##      $Config, persistent across calls:
##
##      ->{NumSweeps}       Number of saved sweeps
##      ->{NumData}         Number of data points in 1 sweep
##      ->{SweepStart}      Start frequency for sweep
##      ->{SweepEnd}        End frequency for sweep
##
##      ->{Labels}          List of frequency labels for each data point
##      ->{Axis}            List of labels for X-axis of display
##
##      ->{Sweep}                   Previous frequency sweep data
##      ->{Sweep}[$N]{Data}         Data for Nth saved sweep
##      ->{Sweep}[$N]{MaxLegend}    Text of max legend
##      ->{Sweep}[$N]{MinLegend}    Text of min legend
##
##########################################################################################
##########################################################################################
##
##  MIT LICENSE
##
##  Permission is hereby granted, free of charge, to any person obtaining a copy of
##    this software and associated documentation files (the "Software"), to deal in
##    the Software without restriction, including without limitation the rights to
##    use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
##    of the Software, and to permit persons to whom the Software is furnished to do
##    so, subject to the following conditions:
##
##  The above copyright notice and this permission notice shall be included in
##    all copies or substantial portions of the Software.
##
##  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
##    INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
##    PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
##    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
##    OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
##    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
##
##########################################################################################
##########################################################################################

use strict;
use warnings FATAL => qw(uninitialized);
use Carp;

our $VERSION = '1.0';

use File::Slurp;
use File::Basename;
use Math::Round;

use FindBin      qw($RealScript);
use Getopt::Long qw(:config no_ignore_case);

use Win32::TieRegistry( Delimiter=>"/", ArrayValues=>0 );
use Imager;
use Imager::Screenshot 'screenshot';

use Iduino;
use Display::Chart1H;
use Site::ConfigFile;

##########################################################################################
##########################################################################################
##
## Data declarations
##
##########################################################################################
##########################################################################################

use constant CONFIG_FILE  => "Transducer.dat";

my $Iduino;
my $Display;
my $Config;

$| = 1;                                             # Flush output immediately

my %Args = ();

#
# These next are used for initializing the config when no saved file data is available.
#
# Once a scan is issued, the system will use actual values.
#
use constant SAVED_SWEEPS    => 20;                 # Number of saved freq sweeps
use constant SWEEP_START     => 20000;
use constant SWEEP_END       => 32000;
use constant DEFAULT_DATALEN => 400;

use constant ADC_MAX         => 0x3FF;              # Maximum ADC value
use constant ADC_VOLTAGE     => 4.1;                # Voltage output at OC1A
use constant SERIES_R        => 100;                # Resistor in series with xducer

use constant GraphOffset     => 80;                 # Difference in height between graphs

##########################################################################################
##########################################################################################
##
## Argument processing
##
##########################################################################################
##########################################################################################

exit HELP_MESSAGE()
    unless GetOptions(\%Args,
        "h|help", "v|version");

exit HELP_MESSAGE()
    if $Args{h};

exit VERSION_MESSAGE()
    if $Args{v} || $Args{V};

sub HELP_MESSAGE {
    #
    # Print the text in the preamble of the script (at the top of this file) 
    #   for the help message.
    #
    my @Usage = read_file($RealScript);

    shift @Usage
        until $Usage[0] =~ /USAGE/;

    shift @Usage;           # Skip USAGE line

    print "\n";
    print "Usage: ";
    while(1) {
        my $Line = shift @Usage;
        last
            if $Line =~ /EXAMPLE/;

        $Line =~ s/\#\#//;

        print $Line;
        }

    return 0;
    }

sub VERSION_MESSAGE {
    print "\n";
    print basename($0) . " version $VERSION\n";

    return 0;
    }

##########################################################################################
##########################################################################################
##
## Load previous data, if any
##
##########################################################################################
##########################################################################################

if( -e CONFIG_FILE ) { $Config = LoadConfigFile(CONFIG_FILE); }
else                 { InitConfig(); }

##########################################################################################
##########################################################################################
##
## Find an Arduino connected to a serial port
##
##########################################################################################
##########################################################################################

$Iduino = Iduino->new();

$Iduino->FindPort()
    or die "Cannot find Iduino on any serial port ($!)";

print "\n"
    foreach (0 .. 10);

print "Iduino found on port $Iduino->{PortName}\n";

##########################################################################################
##########################################################################################
##
## Display data and take commands from the user
##
##########################################################################################
##########################################################################################

while(1) {
    PlotData();
    ProcessCommand();
    }

##########################################################################################
##########################################################################################
#
# PlotData - Plot the current data set
#
# Inputs:   None.
#
# Outputs:  None.
#
sub PlotData {

    $Display = Display::Chart1H->new({StayOnTop => 1,
                                      Last      => $Config->{NumData}-1,
                                      Height    => 0.5,
                                      ExtraY    => 1.2})
        unless defined $Display;

    #
    # Note: We don't use (or show) the histogram, so set that section to zero
    #
    $Display->HistData([(0) x $Config->{NumData}]);
    $Display->SetAxisData($Config->{Axis});

    my $Offset = 0;
    foreach my $Sweep (@{$Config->{Sweep}}) {
        last
            if SweepIsBlank($Sweep);

        my $Graph;
        push @$Graph,$_+$Offset
            foreach @{$Sweep->{Data}};

        $Display->PlotData($Graph,$Sweep->{MinLegend});
        $Offset += 20;
        }

    $Display->Update();
    };


##########################################################################################
##########################################################################################
#
# ProcessCommand - Process 1 user command
#
# Inputs:   None.
#
# Outputs:  None.
#
sub ProcessCommand {

    print "S            Sweep frequency\n";
    print "SD <file>    Save current data to specified file\n";
    print "SS <file>    Screenshot, save to file\n";
    print "C            Clear all sweeps\n";
    print "D            Delete last sweep\n";
    print "Q            Quit/exit the program\n";
    print "X            Quit/exit the program\n";
    print "\n";
    print "Enter command: ";

    my $Input = <STDIN>;

    #
    # CTRL-C comes in as an indefined input
    #
    exit
        unless defined $Input;

    chomp $Input;

    my ($Command,$File) = split / /,$Input;
    $Command = uc $Command;

    if( $Command eq "SD" ) {
        SaveData($File);
        return;
        }

    if( $Command eq "SS" ) {
        ScreenShot($File);
        return;
        }

    if( $Command eq "S" ||
        $Command eq "SW" ) {
        FreqSweep();
        PlotData();
        return;
        }

    if( $Command eq "C" ) {
        InitConfig();
        return;
        }

    if( $Command eq "D" ) {
        shift @{$Config->{Sweep}};
        return;
        }

    if( $Command eq "Q" || $Command eq "X" ) {
        SaveConfigFile(CONFIG_FILE,$Config);
        exit(0);
        }

    #
    # Not a recognized command. Let the user know he goofed.
    #
    print "\007Unrecognized Command.\n\n";
    }


##########################################################################################
##########################################################################################
#
# FreqSweep - Sweep the frequency, collect MIN and MAX data
#
# Inputs:   None.
#
# Outputs:  None.
#
sub FreqSweep {

    ######################################################################################
    #
    # Trigger a sweep on the Iduino and capture the resulting data
    #
#    $Iduino->WriteMsg("S1");
    $Iduino->WriteMsg("SW 26000 30000 10");

    my $MinLegend = "";
    my $MaxLegend = "";

    my $Data   = [];
    my $Labels = [];

    while( my $Response = $Iduino->ReadMsg() ) {

        $Response =~ s///g;       # Remove trailing CR

#       print "=$Response=\n";

        next
            unless $Response =~ /:/;

        #
        # Pull out min value, save as chart label for later
        #
        if( $Response =~ /Min/ ) {
            print "$Response\n";
            $Response  =~ /Min at: (\d+) Hz \((\d+)\)/;
            my $Freq   = $1;
            my $Value  = $2;
            $MinLegend = "Min = $Freq Hz";
            next;
            }

        #
        # Pull out max value, save as chart label for later
        #
        if( $Response =~ /Max/ ) {
            print "$Response\n";
            $Response =~ /Max at: (\d+) Hz \((\d+)\)/;
            my $Freq  = $1;
            my $Value = $2;
            $MaxLegend = "Max = $Freq Hz";
            next;
            }

        my ($Label,$Value) = split /:/,$Response;

#        $Value  = $Value/ADC_MAX;               # ADC to proportion
#        $Value *= ADC_VOLTAGE;                  # Proportion to V[adc]
#        $Value += 1;                            # Plus diode drop = value at transducer
#        $Value  = SERIES_R*ADC_VOLTAGE/$Value;  # Convert to impedance

        push @$Labels,$Label;
        push @$Data  ,(0+$Value);   # Gets rid of spaces in text
        }

    ######################################################################################
    #
    # We've read the Iduino response into local vars, now adjust the saved data
    #   appropriately.
    #

    #
    # It's possible that the Iduino program changed in some manner, causing the saved
    #   data to mismatch the recently acquired set. (Not likely, but possible.)
    #
    # If this has happened, clear out/reinitialize the saved data with info from the new
    #
    InitConfig($#{$Data},$Labels->[0],$Labels->[-1])
        if $#{$Data} != $Config->{NumData};

    $Config->{Labels} = [ @$Labels ];
    MakeAxis();

    pop     @{$Config->{Sweep}};
    unshift @{$Config->{Sweep}},{ Data      => $Data,
                                  MinLegend => $MinLegend,
                                  MaxLegend => $MaxLegend };
    }

##########################################################################################
##########################################################################################
#
# InitConfig - Initialize config struct, based on params
#
# Inputs:   Number of saved       freq sweeps
#           Number of elements in freq sweep
#           Start freq of sweep 
#           End freq of sweep
#
# Outputs:  None.
#
sub InitConfig {

    $Config = undef;

    $Config->{NumSweeps}  = shift // SAVED_SWEEPS;
    $Config->{NumData}    = shift // DEFAULT_DATALEN;
    $Config->{SweepStart} = shift // SWEEP_START;
    $Config->{SweepEnd}   = shift // SWEEP_END;

    #
    # Set up a reasonable X-axis legend for the sweep.
    #
    for( my $i = 0; $i < $Config->{NumData}; $i++ ) {
        $Config->{Labels}[$i] = $Config->{SweepStart} + $i*
                round ($Config->{SweepEnd} - $Config->{SweepStart})/$Config->{NumData};
        }

    foreach (0 .. $Config->{NumSweeps}-1) {
        $Config->{Sweep}[$_]{     Data} = [(0) x $Config->{NumData}];
        $Config->{Sweep}[$_]{MaxLegend} = "";
        $Config->{Sweep}[$_]{MinLegend} = "";
        }

    #
    # Setup a reasonable axis by using every tenth label
    #
    for( my $i = 0; $i < $Config->{NumData}; $i++ ) {
        if( ($i % 10) == 0 ) { push @{$Config->{Axis}},$Config->{Labels}[$i]; }
        else                 { push @{$Config->{Axis}},"\"\""; }
        }
    }

##########################################################################################
##########################################################################################
#
# MakeAxis - Make new X-axis, based on labels
#
# Inputs:   None.
#
# Outputs:  None.
#
sub MakeAxis {

    #
    # Setup a reasonable axis by using every tenth label
    #
    $Config->{Axis} = undef;

    for( my $i = 0; $i < $Config->{NumData}; $i++ ) {
        if( ($i % 10) == 0 ) { 
            if( defined $Config->{Labels}[$i] ) { push @{$Config->{Axis}},$Config->{Labels}[$i]; } 
            else                                { push @{$Config->{Axis}},"XX"; } 
            }
        else                 { push @{$Config->{Axis}},"\"\""; }
        }
    }


##########################################################################################
##########################################################################################
#
# ScreenShot - Save screenshot to specified file
#
# Inputs:   Filename to save to
#
# Outputs:  None.
#
sub ScreenShot {
    my $File = shift;

    print "Saving screenshot to $File\n";

    my $img = screenshot();
    $img->write(file=>$File);
    }


##########################################################################################
##########################################################################################
#
# SweepIsblank - Return TRUE if indexed sweep is blank
#
# Inputs:   Sweep
#
# Outputs:  TRUE  if sweep if blank
#           FALSE otherwise
#
sub SweepIsBlank {
    my $Sweep = shift;

    return 1
        if $Sweep->{Data}[0] == 0;

    return 0;
    }

##########################################################################################
##########################################################################################
#
# SaveData - Save data to specified file
#
# Inputs:   Filename to save to
#
# Outputs:  None.
#
sub SaveData {
    my $File = shift;

    print "Saving data to $File\n";

    open (OUTFILE, ">>$File");
    print OUTFILE "$Config->{Labels}->[$_]: $Config->{Sweep}[0]{Data}->[$_]\n"
        foreach 0 .. $#{$Config->{Sweep}[0]{Data}};
    close (OUTFILE); 
    }
